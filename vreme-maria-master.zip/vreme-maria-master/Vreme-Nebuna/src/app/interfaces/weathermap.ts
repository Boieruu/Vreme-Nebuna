interface HeatmapOptions {
  radius: number;
  gradient: { [key: number]: string };
}

export default HeatmapOptions;
